package PracticeProject9;

public class Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Declare and initialize an array of integers
        int[] arr = {5, 8, 2, 1, 7};

        // Calculate the sum of array elements
        int sum = 0;
        for (int i = 0; i < arr.length; i++) {
            sum += arr[i];
        }
        // Print the sum of an Array
        System.out.println(sum);

        // Display the array elements
        System.out.print("Array Elements: ");
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i] + " ");
        }

	}

}
