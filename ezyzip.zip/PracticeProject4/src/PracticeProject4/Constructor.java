package PracticeProject4;

public class Constructor {
	public Constructor() {
        System.out.println("Default Constructor");
    }

    // Parameterized Constructor
    public Constructor(String message) {
        System.out.println("Parameterized Constructor: " + message);
    }

    // Copy Constructor
    public Constructor(Constructor other) {
        System.out.println("Copy Constructor: " + other.getMessage());
    }

    public String getMessage() {
        return "This is a message from the object.";
    }
    
    public Constructor(int a, int b) {
    	System.out.println(a+b);
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Constructor(); // Default Constructor
        new Constructor("Hello from parameterized constructor"); // Parameterized Constructor

        // Creating an object and using copy constructor
        Constructor originalObject = new Constructor("Original object message");
        new Constructor(originalObject); // Copy Constructor
        new Constructor(5,6);

	}

}
