package PracticeProject1;

public class Project {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int integerValue = 100;
        long longValue = integerValue; // int to long

        float floatValue = longValue; // long to float
        double doubleValue = floatValue; // float to double

        System.out.println("Implicit Type Casting:");
        System.out.println("int to long: " + longValue);
        System.out.println("long to float: " + floatValue);
        System.out.println("float to double: " + doubleValue);

        // Explicit Type Casting (Narrowing)
        double doubleNumber = 123.456;
        float floatNumber = (float) doubleNumber; // double to float

        long longNumber = (long) floatNumber; // float to long
        int integerNumber = (int) longNumber; // long to int

        System.out.println("\nExplicit Type Casting:");
        System.out.println("double to float: " + floatNumber);
        System.out.println("float to long: " + longNumber);
        System.out.println("long to int: " + integerNumber);

	}

}
